/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sortingalgorithm;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 *
 * @author Loren
 */
// Java program for implementation of Bubble Sort
public class Bubble {
	public void bubbleSort(int arr[])
	{
            long time1 = System.currentTimeMillis();
            int n = arr.length;
            for (int i = 0; i < n - 1; i++)
                    for (int j = 0; j < n - i - 1; j++)
                            if (arr[j] > arr[j + 1]) {
                                    // swap arr[j+1] and arr[j]
                                    int temp = arr[j];
                                    arr[j] = arr[j + 1];
                                    arr[j + 1] = temp;
                            }
            long time2 = System.currentTimeMillis();
            long time = time2 - time1;
            System.out.println("Sort took " + time + " milliseconds.");
            System.out.println("\n");
	}
       	
	//Read array list
	public static int[] getFile() throws IOException {
		int[] ints = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\15000ranNum.txt"))
                .mapToInt(Integer::parseInt).toArray();
		return ints;
	}

	/* Prints the array */
	void printArray(int arr[])
	{
		int n = arr.length;
		for (int i = 0; i < n; ++i)
			System.out.print(arr[i] + " ");
		System.out.println();
	}

	// Driver method to test above
	public static void main(String args[]) throws IOException
	{
		Bubble ob = new Bubble();
		int arr[] =  Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option1.txt"))
                .mapToInt(Integer::parseInt).toArray();
		ob.bubbleSort(arr);
		System.out.println("Sorted array");
		ob.printArray(arr);
                
	}
}

