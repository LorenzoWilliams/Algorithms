/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sortingalgorithm;

/**
 *
 * @author Loren
 */
public class Selection
{
	void selectionSort(int arr[])
	{
            long time1 = System.currentTimeMillis();
            int n = arr.length;

            // One by one move boundary of unsorted subarray
            for (int i = 0; i < n-1; i++)
            {
                    // Find the minimum element in unsorted array
                    int min_idx = i;
                    for (int j = i+1; j < n; j++)
                            if (arr[j] < arr[min_idx])
                                    min_idx = j;

                    // Swap the found minimum element with the first
                    // element
                    int temp = arr[min_idx];
                    arr[min_idx] = arr[i];
                    arr[i] = temp;
            }
            long time2 = System.currentTimeMillis();
            long time = time2 - time1;
            System.out.println("Sort took " + time + " milliseconds.");
            System.out.println("\n");
	}

	// Prints the array
	void printArray(int arr[])
	{
		int n = arr.length;
		for (int i=0; i<n; ++i)
			System.out.print(arr[i]+" ");
		System.out.println();
	}

	// Driver code to test above
	public static void main(String args[])
	{
		Selection ob = new Selection();
		int arr[] = {64,25,12,22,11};
		ob.selectionSort(arr);
		System.out.println("Sorted array");
		ob.printArray(arr);
	}
}
/* This code is contributed by Rajat Mishra*/
