/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sortingalgorithm;

/**
 *
 * @author Loren
 */
// Java program for implementation of Insertion Sort
public class Insertion {
	/*Function to sort array using insertion sort*/
	void insertionSort(int arr[])
	{
            long time1 = System.currentTimeMillis();
            int n = arr.length;
            for (int i = 1; i < n; ++i) {
                    int key = arr[i];
                    int j = i - 1;

                    /* Move elements of arr[0..i-1], that are
                    greater than key, to one position ahead
                    of their current position */
                    while (j >= 0 && arr[j] > key) {
                            arr[j + 1] = arr[j];
                            j = j - 1;
                    }
                    arr[j + 1] = key;
            }
            long time2 = System.currentTimeMillis();
            long time = time2 - time1;
            System.out.println("Sort took " + time + " milliseconds.");
            System.out.println("\n");
	}

	/* A utility function to print array of size n*/
	static void printArray(int arr[])
	{
		int n = arr.length;
		for (int i = 0; i < n; ++i)
			System.out.print(arr[i] + " ");

		System.out.println();
	}

	// Driver method
	public static void main(String args[])
	{
		int arr[] = { 12, 11, 13, 5, 6 };

		Insertion ob = new Insertion();
		ob.insertionSort(arr);

		printArray(arr);
	}
}