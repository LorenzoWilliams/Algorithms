/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.sortingalgorithm;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 *
 * @author Loren
 */
public class SortingAlgorithm {

    public static void main(String[] args) throws IOException {
        Scanner scan = new Scanner(System.in);
        
        int selectMethod=0;        
        while(selectMethod!=-1){
                 System.out.println("\n");
            System.out.println("\t*------Main Menu------*");
            System.out.println("\t*   1: Bubble Sort    *");
            System.out.println("\t*   2: Heap Sort      *");
            System.out.println("\t*   3: Insertion Sort *");
            System.out.println("\t*   4: Merge Sort     *");
            System.out.println("\t*   5: Quick Sort     *");
            System.out.println("\t*   6: Selection Sort *");
            System.out.println("\t*   7: Exit           *");
            System.out.println("\t*--------****---------*");
            System.out.println("Please Select and Option: ");
           int choice = scan.nextInt();
           
            switch (choice) {
                case 1:
                    
                        BubbleSubMenu();
                    break;


                case 2:
                                    
                        HeapSubMenu();
                    
                    break;

                    
                case 3:
                        InsertionSubMenu();
                    break;


                case 4:
                        MergeSubMenu();
                    break;
                                    
                case 5:
                        QuickSubMenu();
                    break;


                case 6:
                        SelectionSubMenu();
                    break;
                    
                case 7:
                    //program Exit
                    System.exit(0);
                default:
                    break;
            }
        }
    }
 
       public static void BubbleSubMenu() throws IOException 
    {
        Scanner scanOption = new Scanner(System.in);
        
      //  Runtime.getRuntime().exec("cls");
      
      int selectMethod=0;        
        while(selectMethod!=-1){
            System.out.println("\t*--Bubble Sort Sub Menu--*");
            System.out.println("\t*        1: 15000        *");
            System.out.println("\t*        2: 65000        *");
            System.out.println("\t*        3: 150000       *");
            System.out.println("\t*        4: Exit         *");
            System.out.println("\t*----------****----------*\n");
            System.out.println("Please Select and Option: ");

            int choice = scanOption.nextInt();
           
            switch (choice) {
                case 1 -> {
                    Bubble bubble1 = new Bubble();
                    int[] int1 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option1.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    bubble1.bubbleSort(int1);
                    bubble1.printArray(int1);
                    System.out.println("\n");
                }
                        
                case 2 -> {
                    Bubble bubble2 = new Bubble();
                    int[] int2 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option2.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    bubble2.bubbleSort(int2);
                    bubble2.printArray(int2);
                    System.out.println("\n");
                }
                    
                case 3 -> {
                    Bubble bubble3 = new Bubble();
                    int[] int3 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option3.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    bubble3.bubbleSort(int3);
                    bubble3.printArray(int3);
                    System.out.println("\n");
                }
                
                case 4 -> {
                    //program Exit
                    return;
                }
                default -> {
                }
            }
        }
    }

    private static void HeapSubMenu() throws IOException 
    {
        Scanner scanOption = new Scanner(System.in);
        
      //  Runtime.getRuntime().exec("cls");
      
      int selectMethod=0;        
        while(selectMethod!=-1){
            System.out.println("\t*---Heap Sort Sub Menu---*");
            System.out.println("\t*       1: 15000         *");
            System.out.println("\t*       2: 65000         *");
            System.out.println("\t*       3: 150000        *");
            System.out.println("\t*       4: Exit          *");
            System.out.println("\t*---------****-----------*\n");
            System.out.println("Please Select and Option: ");

            int choice = scanOption.nextInt();
           
            switch (choice) {
                case 1 -> {
                    Heap heap1 = new Heap();
                    int[] int1 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option1.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    heap1.heapSort(int1);
                    Heap.printArray(int1);
                    System.out.println("\n");
                }
                        
                case 2 -> {
                    Heap heap2 = new Heap();
                    int[] int2 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option2.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    heap2.heapSort(int2);
                    Heap.printArray(int2);
                    System.out.println("\n");
                }
                    
                case 3 -> {
                    Heap heap3 = new Heap();
                    int[] int3 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option3.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    heap3.heapSort(int3);
                    Heap.printArray(int3);
                    System.out.println("\n");
                }
                
                case 4 -> {
                    //program Exit
                    return;
                }
                default -> {
                }
            }
        }
    }

    private static void InsertionSubMenu() throws IOException 
    {
        Scanner scanOption = new Scanner(System.in);
        
      //  Runtime.getRuntime().exec("cls");
      
      int selectMethod=0;        
        while(selectMethod!=-1){
            System.out.println("\t*---Insertion Sort Sub Menu---*");
            System.out.println("\t*           1: 15000          *");
            System.out.println("\t*           2: 65000          *");
            System.out.println("\t*           3: 150000         *");
            System.out.println("\t*           4: Exit           *");
            System.out.println("\t*-------------****------------*\n");
            System.out.println("Please Select and Option: ");

            int choice = scanOption.nextInt();
           
            switch (choice) {
                case 1 -> {
                    Insertion insertion1 = new Insertion();
                    int[] int1 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option1.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    insertion1.insertionSort(int1);
                    Insertion.printArray(int1);
                    System.out.println("\n");
                }
                        
                case 2 -> {
                    Insertion insertion2 = new Insertion();
                    int[] int2 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option2.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    insertion2.insertionSort(int2);
                    Insertion.printArray(int2);
                    System.out.println("\n");
                }
                    
                case 3 -> {
                    Insertion insertion3 = new Insertion();
                    int[] int3 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option3.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    insertion3.insertionSort(int3);
                    Insertion.printArray(int3);
                    System.out.println("\n");
                }
                
                case 4 -> {
                    //program Exit
                    return;
                }
                default -> {
                }
            }
        }
    }

    private static void MergeSubMenu() throws IOException 
    {
        Scanner scanOption = new Scanner(System.in);
        
      //  Runtime.getRuntime().exec("cls");
      
      int selectMethod=0;        
        while(selectMethod!=-1){
            System.out.println("\t*---Merge Sort Sub Menu-----*");
            System.out.println("\t*        1: 15000           *");
            System.out.println("\t*        2: 65000           *");
            System.out.println("\t*        3: 150000          *");
            System.out.println("\t*        4: Exit            *");
            System.out.println("\t*----------****-------------*\n");
            System.out.println("Please Select and Option: ");

            int choice = scanOption.nextInt();
           
            switch (choice) {
                case 1 -> {
                    Merge merge1 = new Merge();
                    int[] int1 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option1.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    merge1.mergeSort(int1, 0, int1.length - 1);
                    Merge.printArray(int1);
                    System.out.println("\n");
                }
                        
                case 2 -> {
                    Merge merge2 = new Merge();
                    int[] int2 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option2.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    merge2.mergeSort(int2, 0, int2.length - 1);
                    Merge.printArray(int2);
                    System.out.println("\n");
                }
                    
                case 3 -> {
                    Merge merge3 = new Merge();
                    int[] int3 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option3.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    merge3.mergeSort(int3, 0, int3.length - 1);
                    Merge.printArray(int3);
                    System.out.println("\n");
                }
                
                case 4 -> {
                    //program Exit
                    return;
                }
                default -> {
                }
            }
        }
    }

    private static void QuickSubMenu() throws IOException 
    {
        Scanner scanOption = new Scanner(System.in);
        
      //  Runtime.getRuntime().exec("cls");
      
      int selectMethod=0;        
        while(selectMethod!=-1){
            System.out.println("\t*---Quick Sort Sub Menu---*");
            System.out.println("\t*        1: 15000         *");
            System.out.println("\t*        2: 65000         *");
            System.out.println("\t*        3: 150000        *");
            System.out.println("\t*        4: Exit          *");
            System.out.println("\t*----------****-----------*\n");
            System.out.println("Please Select and Option: ");

            int choice = scanOption.nextInt();
           
            switch (choice) {
                case 1 -> {
                    int[] int1 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option1.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    Quick.quickSort(int1, 0, int1.length - 1);
                    Quick.printArray(int1);
                    System.out.println("\n");
                }

                        
                case 2 -> {
                    int[] int2 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option2.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    Quick.quickSort(int2, 0, int2.length - 1);
                    Quick.printArray(int2);
                    System.out.println("\n");
                }

                    
                case 3 -> {
                    int[] int3 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option3.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    Quick.quickSort(int3, 0, int3.length - 1);
                    Quick.printArray(int3);
                    System.out.println("\n");
                }

                
                case 4 -> {
                    //program Exit
                    return;
                }
                default -> {
                }
            }
        }
    }

    private static void SelectionSubMenu() throws IOException 
    {
        Scanner scanOption = new Scanner(System.in);
        
      //  Runtime.getRuntime().exec("cls");
      
      int selectMethod=0;        
        while(selectMethod!=-1){
            System.out.println("\t*---Selection Sort Sub Menu---*");
            System.out.println("\t*           1: 15000          *");
            System.out.println("\t*           2: 65000          *");
            System.out.println("\t*           3: 150000         *");
            System.out.println("\t*           4: Exit           *");
            System.out.println("\t*-------------****------------*\n");
            System.out.println("Please Select and Option: ");

            int choice = scanOption.nextInt();
           
            switch (choice) {
                case 1 -> {
                    Selection selection1 = new Selection();
                    int[] int1 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option1.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    selection1.selectionSort(int1);
                    selection1.printArray(int1);
                    System.out.println("\n");
                }
                        
                case 2 -> {
                    Selection selection2 = new Selection();
                    int[] int2 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option2.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    selection2.selectionSort(int2);
                    selection2.printArray(int2);
                    System.out.println("\n");
                }
                    
                case 3 -> {
                    Selection selection3 = new Selection();
                    int[] int3 = Files.lines(Paths.get("C:\\Users\\Loren.DESKTOP-4ILE5PT\\OneDrive\\Documents\\NetBeansProjects\\SortingAlgorithm\\src\\main\\files\\option3.txt"))
                            .mapToInt(Integer::parseInt).toArray();
                    selection3.selectionSort(int3);
                    selection3.printArray(int3);
                    System.out.println("\n");
                }
                
                case 4 -> {
                    //program Exit
                    return;
                }
                default -> {
                }
            }
        }
    }
}
    

    